async function getWeather() {
  const city = document.getElementById("cityInput").value;
  const apiKey = "YOUR_API_KEY"; // यहां अपनी OpenWeatherMap API Key डालें
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=hi`;

  const response = await fetch(url);
  const data = await response.json();

  if (data.cod === 200) {
    document.getElementById("result").innerHTML =
      `<strong>${data.name}</strong> में तापमान है <strong>${data.main.temp}°C</strong><br>स्थिति: ${data.weather[0].description}`;
  } else {
    document.getElementById("result").innerHTML = "शहर नहीं मिला।";
  }
}
